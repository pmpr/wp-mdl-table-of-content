<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a8c27f2e4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\TableOfContent; class Ajax extends Container { }
