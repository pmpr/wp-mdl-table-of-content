<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6606aca9bd741             |
    |_______________________________________|
*/
 namespace Pmpr\Module\TableOfContent; class Ajax extends Container { }
