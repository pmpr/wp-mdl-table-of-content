<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684011ee70ee             |
    |_______________________________________|
*/
 namespace Pmpr\Module\TableOfContent; class Ajax extends Container { }
