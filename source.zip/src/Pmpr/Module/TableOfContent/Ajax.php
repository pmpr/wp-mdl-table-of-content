<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e4257329e8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\TableOfContent; class Ajax extends Container { }
