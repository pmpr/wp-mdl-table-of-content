<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66870851de5aa             |
    |_______________________________________|
*/
 namespace Pmpr\Module\TableOfContent; class Ajax extends Container { }
