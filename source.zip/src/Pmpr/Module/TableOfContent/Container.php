<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4ad87cfe1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\TableOfContent; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { public function esciskwmewkgwaik() : array { return Setting::symcgieuakksimmu()->esciskwmewkgwaik(); } public function gmiiaymeiwkykcym(string $ewgwqamkygiqaawc, bool $boeioycsyqgqmoeu = true) : bool { $yuumukkaswwoywya = ''; foreach ($this->weysguygiseoukqw(Setting::skqaqgkgaueeyosa, []) as $iuimqckcgwwkgygo) { if ($boeioycsyqgqmoeu) { $yuumukkaswwoywya .= "\x68{$iuimqckcgwwkgygo}\x3a\156\157\x74\x28\x5b\144\141\x74\141\x2d\x74\162\x61\x6e\x73\x6c\x61\164\x65\135\x29\54\40\150{$iuimqckcgwwkgygo}\x5b\x64\141\x74\141\55\164\x72\x61\x6e\163\x6c\141\164\x65\75\x27\x6e\157\47\x5d\x2c"; } else { $yuumukkaswwoywya .= "\x68{$iuimqckcgwwkgygo}\x3a\156\x6f\164\x28\133\151\x64\x5d\x29\x2c"; } } $yuumukkaswwoywya = rtrim($yuumukkaswwoywya, "\54"); return !$this->caokeucsksukesyo()->gkksucgseqqemesc()->has(stripslashes($ewgwqamkygiqaawc), $yuumukkaswwoywya); } }
