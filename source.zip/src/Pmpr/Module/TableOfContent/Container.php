<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce11d8b9e7b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\TableOfContent; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { public function ikcgmcycisiccyuc() { $this->settingObj = Setting::symcgieuakksimmu(); } public function esciskwmewkgwaik() : array { return Setting::symcgieuakksimmu()->esciskwmewkgwaik(); } public function gmiiaymeiwkykcym(string $ewgwqamkygiqaawc, bool $boeioycsyqgqmoeu = true) : bool { $yuumukkaswwoywya = ''; foreach ($this->weysguygiseoukqw(Setting::skqaqgkgaueeyosa, []) as $iuimqckcgwwkgygo) { if ($boeioycsyqgqmoeu) { goto suqkuqygkkgwyaie; } $yuumukkaswwoywya .= "\x68{$iuimqckcgwwkgygo}\72\156\157\x74\x28\x5b\x69\x64\135\51\54"; goto soaccwqimeksgwiw; suqkuqygkkgwyaie: $yuumukkaswwoywya .= "\x68{$iuimqckcgwwkgygo}\72\x6e\157\x74\50\x5b\x64\141\x74\141\55\x74\162\x61\x6e\163\154\x61\164\x65\x5d\x29\54\x20\150{$iuimqckcgwwkgygo}\x5b\144\x61\x74\141\x2d\164\162\141\x6e\x73\154\141\x74\145\x3d\47\x6e\157\47\x5d\54"; soaccwqimeksgwiw: aegysmeecgcgayyw: } gaomwagkcciesyqy: $yuumukkaswwoywya = rtrim($yuumukkaswwoywya, "\54"); return !$this->caokeucsksukesyo()->gkksucgseqqemesc()->has(stripslashes($ewgwqamkygiqaawc), $yuumukkaswwoywya); } }
