<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8a6e45cf             |
    |_______________________________________|
*/
 namespace Pmpr\Module\TableOfContent; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { public function ikcgmcycisiccyuc() { $this->settingObj = Setting::symcgieuakksimmu(); } public function esciskwmewkgwaik() : array { return Setting::symcgieuakksimmu()->esciskwmewkgwaik(); } public function gmiiaymeiwkykcym(string $ewgwqamkygiqaawc, bool $boeioycsyqgqmoeu = true) : bool { $yuumukkaswwoywya = ''; foreach ($this->weysguygiseoukqw(Setting::skqaqgkgaueeyosa, []) as $iuimqckcgwwkgygo) { if ($boeioycsyqgqmoeu) { goto gaomwagkcciesyqy; } $yuumukkaswwoywya .= "\x68{$iuimqckcgwwkgygo}\72\156\157\x74\x28\x5b\x69\144\x5d\x29\54"; goto aegysmeecgcgayyw; gaomwagkcciesyqy: $yuumukkaswwoywya .= "\150{$iuimqckcgwwkgygo}\x3a\x6e\157\164\50\x5b\x64\x61\164\x61\55\x74\162\141\x6e\163\154\141\164\145\x5d\51\54\40\150{$iuimqckcgwwkgygo}\133\144\x61\x74\x61\55\x74\x72\141\x6e\163\x6c\x61\164\145\75\x27\x6e\157\x27\135\54"; aegysmeecgcgayyw: esuiysskoweawsue: } uqqaiagaeqgqgaiy: $yuumukkaswwoywya = rtrim($yuumukkaswwoywya, "\54"); return !$this->caokeucsksukesyo()->gkksucgseqqemesc()->has(stripslashes($ewgwqamkygiqaawc), $yuumukkaswwoywya); } }
