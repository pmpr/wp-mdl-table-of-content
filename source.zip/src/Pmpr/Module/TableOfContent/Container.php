<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ecbf80ec9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\TableOfContent; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { public function ikcgmcycisiccyuc() { $this->settingObj = Setting::symcgieuakksimmu(); } public function esciskwmewkgwaik() : array { return Setting::symcgieuakksimmu()->esciskwmewkgwaik(); } public function gmiiaymeiwkykcym(string $ewgwqamkygiqaawc, bool $boeioycsyqgqmoeu = true) : bool { $yuumukkaswwoywya = ''; foreach ($this->weysguygiseoukqw(Setting::skqaqgkgaueeyosa, []) as $iuimqckcgwwkgygo) { if ($boeioycsyqgqmoeu) { goto gaomwagkcciesyqy; } $yuumukkaswwoywya .= "\x68{$iuimqckcgwwkgygo}\x3a\x6e\157\164\50\133\x69\x64\x5d\51\x2c"; goto aegysmeecgcgayyw; gaomwagkcciesyqy: $yuumukkaswwoywya .= "\x68{$iuimqckcgwwkgygo}\x3a\x6e\x6f\164\x28\x5b\x64\x61\x74\x61\x2d\x74\162\x61\x6e\x73\154\141\164\145\x5d\x29\54\x20\150{$iuimqckcgwwkgygo}\x5b\x64\141\x74\x61\x2d\x74\162\x61\x6e\x73\154\x61\x74\x65\75\x27\x6e\157\x27\135\54"; aegysmeecgcgayyw: esuiysskoweawsue: } uqqaiagaeqgqgaiy: $yuumukkaswwoywya = rtrim($yuumukkaswwoywya, "\54"); return !$this->caokeucsksukesyo()->gkksucgseqqemesc()->has(stripslashes($ewgwqamkygiqaawc), $yuumukkaswwoywya); } }
