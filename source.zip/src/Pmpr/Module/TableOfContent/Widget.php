<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68010662b5906             |
    |_______________________________________|
*/
 namespace Pmpr\Module\TableOfContent; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Widget as BaseClass; use Pmpr\Module\TableOfContent\Traits\RenderTrait; class Widget extends BaseClass { use RenderTrait; public function __construct() { parent::__construct(__('Table of Content', PR__MDL__TABLE_OF_CONTENT), __('Display the table of contents.', PR__MDL__TABLE_OF_CONTENT)); } public function ecwgiiuacoaokqkw() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::qescuiwgsyuikume)->gswweykyogmsyawy(__('Title', PR__MDL__TABLE_OF_CONTENT)))->mkksewyosgeumwsa($uuyucgkyusckoaeq->wcwmusaouiqaqeww(Constants::ayscagukkeoucmoe)->gswweykyogmsyawy(__('Collapsible', PR__MDL__TABLE_OF_CONTENT))); } public function gayqqwwuycceosii($ywmkwiwkosakssii = [], $owgumcsyqsamiemg = []) : array { return $this->eeisgyksyecuceue($owgumcsyqsamiemg); } public function qoqyomiqwooaeoiy($ywmkwiwkosakssii = [], $owgumcsyqsamiemg = [], $qookweymeqawmcwo = []) : bool { return $this->uiqcwsowwswommka(); } }
