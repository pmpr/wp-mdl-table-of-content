<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4ad87cfe1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\TableOfContent; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\TableOfContent\Traits\RenderTrait; class Frontend extends Container { use RenderTrait; public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x74\x68\x65\x5f\143\157\x6e\x74\145\x6e\x74", [$this, "\141\151\x6d\x79\x63\155\x6b\167\157\x73\x73\147\141\163\x67\x73"], 999); } public function wigskegsqequoeks() { $this->waqewsckuayqguos(TableOfContent::qmkskkcukqigsimq . "\162\145\x6e\144\145\162", [$this, "\162\x65\x6e\x64\145\x72"]); } public function aimycmkwossgasgs($ewgwqamkygiqaawc) { if ($this->uiqcwsowwswommka()) { $ewgwqamkygiqaawc = $this->wgqqgewcmcemoewo() . $ewgwqamkygiqaawc; } return $ewgwqamkygiqaawc; } public function wgqqgewcmcemoewo() : string { return $this->iuygowkemiiwqmiw("\x66\162\157\x6e\164\145\x6e\x64", $this->eeisgyksyecuceue([Constants::qescuiwgsyuikume => $this->weysguygiseoukqw(Setting::aekmoagaweyqgyeo), Constants::ayscagukkeoucmoe => $this->weysguygiseoukqw(Constants::ayscagukkeoucmoe)])); } public function render() { if ($this->uiqcwsowwswommka()) { echo $this->wgqqgewcmcemoewo(); } } }
