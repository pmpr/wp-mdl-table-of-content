<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a8c27f2e4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\TableOfContent; use Pmpr\Module\TableOfContent\Traits\RenderTrait; class Frontend extends Container { use RenderTrait; public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x74\150\145\137\x63\x6f\156\164\145\x6e\164", [$this, "\x61\151\x6d\171\x63\x6d\x6b\167\157\163\163\x67\141\x73\147\163"], 999); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu($this->ygyygikyocoymgaw(self::qmkskkcukqigsimq . "\x72\145\x6e\x64\x65\162"), [$this, "\162\x65\x6e\x64\x65\162"]); } public function aimycmkwossgasgs($ewgwqamkygiqaawc) { if (!$this->uiqcwsowwswommka()) { goto acaqummmoyiemqss; } $ewgwqamkygiqaawc = $this->wgqqgewcmcemoewo() . $ewgwqamkygiqaawc; acaqummmoyiemqss: return $ewgwqamkygiqaawc; } public function wgqqgewcmcemoewo() : string { return $this->iuygowkemiiwqmiw("\x66\x72\x6f\x6e\164\x65\x6e\x64", $this->eeisgyksyecuceue([self::qescuiwgsyuikume => $this->weysguygiseoukqw(Setting::aekmoagaweyqgyeo), self::ayscagukkeoucmoe => $this->weysguygiseoukqw(self::ayscagukkeoucmoe)])); } public function render() { if (!$this->uiqcwsowwswommka()) { goto suswcqoyyqkkquuo; } echo $this->wgqqgewcmcemoewo(); suswcqoyyqkkquuo: } }
