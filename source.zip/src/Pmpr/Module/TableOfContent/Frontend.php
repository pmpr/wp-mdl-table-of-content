<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684011ee70ee             |
    |_______________________________________|
*/
 namespace Pmpr\Module\TableOfContent; use Pmpr\Module\TableOfContent\Traits\RenderTrait; class Frontend extends Container { use RenderTrait; public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x74\x68\145\x5f\x63\x6f\x6e\164\x65\156\x74", [$this, "\x61\151\x6d\x79\x63\x6d\153\167\x6f\x73\x73\147\x61\x73\147\163"], 999); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu($this->ygyygikyocoymgaw(self::qmkskkcukqigsimq . "\162\145\x6e\144\x65\162"), [$this, "\x72\x65\156\x64\145\x72"]); } public function aimycmkwossgasgs($ewgwqamkygiqaawc) { if (!$this->uiqcwsowwswommka()) { goto cecuyayqoioasumi; } $ewgwqamkygiqaawc = $this->wgqqgewcmcemoewo() . $ewgwqamkygiqaawc; cecuyayqoioasumi: return $ewgwqamkygiqaawc; } public function wgqqgewcmcemoewo() : string { return $this->iuygowkemiiwqmiw("\x66\162\x6f\156\x74\x65\x6e\144", $this->eeisgyksyecuceue([self::qescuiwgsyuikume => $this->weysguygiseoukqw(Setting::aekmoagaweyqgyeo), self::ayscagukkeoucmoe => $this->weysguygiseoukqw(self::ayscagukkeoucmoe)])); } public function render() { if (!$this->uiqcwsowwswommka()) { goto qiaqsassksqiuyae; } echo $this->wgqqgewcmcemoewo(); qiaqsassksqiuyae: } }
