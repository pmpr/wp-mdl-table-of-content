<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6606aca9bd741             |
    |_______________________________________|
*/
 namespace Pmpr\Module\TableOfContent; use Pmpr\Module\TableOfContent\Traits\RenderTrait; class Frontend extends Container { use RenderTrait; public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\164\150\145\137\143\157\156\x74\x65\x6e\164", [$this, "\x61\151\x6d\x79\x63\155\153\167\x6f\163\x73\147\141\x73\x67\163"], 999); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu($this->ygyygikyocoymgaw(self::qmkskkcukqigsimq . "\x72\145\x6e\x64\145\x72"), [$this, "\x72\x65\x6e\x64\x65\162"]); } public function aimycmkwossgasgs($ewgwqamkygiqaawc) { if (!$this->uiqcwsowwswommka()) { goto foeeqckqsyockkak; } $ewgwqamkygiqaawc = $this->wgqqgewcmcemoewo() . $ewgwqamkygiqaawc; foeeqckqsyockkak: return $ewgwqamkygiqaawc; } public function wgqqgewcmcemoewo() : string { return $this->iuygowkemiiwqmiw("\146\162\157\156\x74\x65\156\144", $this->eeisgyksyecuceue([self::qescuiwgsyuikume => $this->weysguygiseoukqw(Setting::aekmoagaweyqgyeo), self::ayscagukkeoucmoe => $this->weysguygiseoukqw(self::ayscagukkeoucmoe)])); } public function render() { if (!$this->uiqcwsowwswommka()) { goto iekumemscwieugqw; } echo $this->wgqqgewcmcemoewo(); iekumemscwieugqw: } }
