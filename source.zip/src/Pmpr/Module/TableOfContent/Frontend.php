<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e4257329e8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\TableOfContent; use Pmpr\Module\TableOfContent\Traits\RenderTrait; class Frontend extends Container { use RenderTrait; public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x74\150\145\x5f\143\x6f\156\x74\x65\156\164", [$this, "\x61\x69\155\x79\x63\155\153\x77\x6f\163\163\x67\x61\163\x67\x73"], 999); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu($this->ygyygikyocoymgaw(self::qmkskkcukqigsimq . "\162\145\156\x64\145\162"), [$this, "\x72\x65\156\x64\145\162"]); } public function aimycmkwossgasgs($ewgwqamkygiqaawc) { if (!$this->uiqcwsowwswommka()) { goto esuiysskoweawsue; } $ewgwqamkygiqaawc = $this->wgqqgewcmcemoewo() . $ewgwqamkygiqaawc; esuiysskoweawsue: return $ewgwqamkygiqaawc; } public function wgqqgewcmcemoewo() : string { return $this->iuygowkemiiwqmiw("\146\x72\x6f\x6e\x74\x65\x6e\144", $this->eeisgyksyecuceue([self::qescuiwgsyuikume => $this->weysguygiseoukqw(Setting::aekmoagaweyqgyeo), self::ayscagukkeoucmoe => $this->weysguygiseoukqw(self::ayscagukkeoucmoe)])); } public function render() { if (!$this->uiqcwsowwswommka()) { goto gaomwagkcciesyqy; } echo $this->wgqqgewcmcemoewo(); gaomwagkcciesyqy: } }
