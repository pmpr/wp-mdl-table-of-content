<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66870851de5aa             |
    |_______________________________________|
*/
 namespace Pmpr\Module\TableOfContent; use Pmpr\Module\TableOfContent\Traits\RenderTrait; class Frontend extends Container { use RenderTrait; public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\164\150\145\x5f\143\x6f\x6e\x74\145\x6e\x74", [$this, "\x61\151\155\171\x63\x6d\153\x77\x6f\x73\x73\x67\x61\163\147\163"], 999); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu($this->ygyygikyocoymgaw(self::qmkskkcukqigsimq . "\x72\145\156\x64\145\x72"), [$this, "\x72\145\156\x64\x65\162"]); } public function aimycmkwossgasgs($ewgwqamkygiqaawc) { if (!$this->uiqcwsowwswommka()) { goto cecuyayqoioasumi; } $ewgwqamkygiqaawc = $this->wgqqgewcmcemoewo() . $ewgwqamkygiqaawc; cecuyayqoioasumi: return $ewgwqamkygiqaawc; } public function wgqqgewcmcemoewo() : string { return $this->iuygowkemiiwqmiw("\x66\162\x6f\x6e\164\x65\x6e\144", $this->eeisgyksyecuceue([self::qescuiwgsyuikume => $this->weysguygiseoukqw(Setting::aekmoagaweyqgyeo), self::ayscagukkeoucmoe => $this->weysguygiseoukqw(self::ayscagukkeoucmoe)])); } public function render() { if (!$this->uiqcwsowwswommka()) { goto qiaqsassksqiuyae; } echo $this->wgqqgewcmcemoewo(); qiaqsassksqiuyae: } }
