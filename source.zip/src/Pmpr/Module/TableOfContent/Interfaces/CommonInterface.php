<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a8c27f2e4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\TableOfContent\Interfaces; interface CommonInterface { const qmkskkcukqigsimq = "\x74\141\x62\154\145\137\157\x66\x5f\143\157\x6e\x74\145\156\x74\137"; const eggmsegugikoumgg = self::qmkskkcukqigsimq . "\156\145\170\x74\137\x74\x72\141\x6e\163\x6c\141\164\x69\157\x6e\137\164\162\x79"; const meawmmkyieiykykg = self::qmkskkcukqigsimq . "\141\x6c\154\157\x77\137\164\162\141\x6e\163\154\141\164\x65"; }
