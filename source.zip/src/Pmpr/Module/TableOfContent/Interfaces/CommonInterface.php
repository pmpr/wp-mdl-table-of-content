<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684011ee70ee             |
    |_______________________________________|
*/
 namespace Pmpr\Module\TableOfContent\Interfaces; interface CommonInterface { const qmkskkcukqigsimq = "\x74\x61\142\154\145\x5f\x6f\146\x5f\143\157\x6e\x74\145\156\164\x5f"; const eggmsegugikoumgg = self::qmkskkcukqigsimq . "\156\x65\170\x74\x5f\164\162\141\156\163\x6c\x61\x74\151\x6f\156\137\164\162\171"; const meawmmkyieiykykg = self::qmkskkcukqigsimq . "\x61\154\154\x6f\x77\137\164\162\x61\x6e\163\x6c\x61\x74\x65"; }
