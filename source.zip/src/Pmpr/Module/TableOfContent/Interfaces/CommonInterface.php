<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6606aca9bd741             |
    |_______________________________________|
*/
 namespace Pmpr\Module\TableOfContent\Interfaces; interface CommonInterface { const qmkskkcukqigsimq = "\164\x61\x62\x6c\145\x5f\157\x66\137\143\x6f\x6e\x74\145\x6e\x74\x5f"; const eggmsegugikoumgg = self::qmkskkcukqigsimq . "\156\145\170\164\x5f\x74\162\141\x6e\163\x6c\141\x74\151\157\156\137\164\162\171"; const meawmmkyieiykykg = self::qmkskkcukqigsimq . "\x61\154\x6c\157\167\x5f\164\x72\141\x6e\163\154\141\164\x65"; }
