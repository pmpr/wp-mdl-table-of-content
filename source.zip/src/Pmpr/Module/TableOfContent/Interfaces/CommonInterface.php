<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66870851de5aa             |
    |_______________________________________|
*/
 namespace Pmpr\Module\TableOfContent\Interfaces; interface CommonInterface { const qmkskkcukqigsimq = "\164\141\142\154\x65\x5f\157\x66\137\143\157\156\164\x65\156\x74\137"; const eggmsegugikoumgg = self::qmkskkcukqigsimq . "\156\x65\x78\164\x5f\164\162\141\156\163\x6c\141\x74\x69\x6f\156\137\x74\162\171"; const meawmmkyieiykykg = self::qmkskkcukqigsimq . "\141\154\x6c\x6f\x77\x5f\164\x72\141\156\x73\x6c\x61\x74\x65"; }
