<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e4257329e8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\TableOfContent\Interfaces; interface CommonInterface { const qmkskkcukqigsimq = "\164\141\x62\x6c\145\x5f\x6f\x66\137\143\x6f\156\x74\145\x6e\164\137"; const eggmsegugikoumgg = self::qmkskkcukqigsimq . "\156\145\x78\164\x5f\164\162\x61\x6e\x73\x6c\x61\x74\x69\x6f\156\137\x74\162\171"; const meawmmkyieiykykg = self::qmkskkcukqigsimq . "\141\154\154\x6f\167\137\x74\162\141\x6e\163\x6c\141\x74\145"; }
