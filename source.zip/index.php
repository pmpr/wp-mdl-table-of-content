<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e4257329e8             |
    |_______________________________________|
*/
 use Pmpr\Module\TableOfContent\TableOfContent; TableOfContent::symcgieuakksimmu();
