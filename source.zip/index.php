<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66870851de5aa             |
    |_______________________________________|
*/
 use Pmpr\Module\TableOfContent\TableOfContent; TableOfContent::symcgieuakksimmu();
